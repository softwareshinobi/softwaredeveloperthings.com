# Please confirm your email :)

## Email Subject

Please confirm your email :)

## Email Body

One more step before downloading all the handbooks ⤵️

Click here to confirm your email!

Thank you! 🥳

- Tech Tutor Troy
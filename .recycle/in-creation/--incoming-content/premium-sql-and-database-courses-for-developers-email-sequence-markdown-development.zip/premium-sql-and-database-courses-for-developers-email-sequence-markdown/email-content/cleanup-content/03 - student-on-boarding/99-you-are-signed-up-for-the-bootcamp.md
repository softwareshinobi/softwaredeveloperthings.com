## You Are Signed Up For The SQL Developer Email Bootcamp

## Email Subject

You're Signed Up For The SQL Developer Email Bootcamp

## Email Body

You're In.

Welcome to the first day of my free 14 day SQL Developer email bootcamp.

My bootcamp is designed to level up your skills and abilities as a database admin & SQL query developer.

The SQL Developer bootcamp is spread over fourteen (14) email lessons delivered to your inbox every morning.

--

In the first lesson we will start with reviewing relational database and SQL at a high level.

--

The first lesson is being sent to you right now. Sit tight.

--

To Your Ascendance,

Tech Tutor Troy

www.techtutortroy.online


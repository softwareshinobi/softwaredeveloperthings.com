# Email Bootcamp: Double Opt-In

## Email Subject

Verify Your Email Address | Tech Tutor Troy

## Email Body

Howdy [[first-name]]!

Please verify that your email address is [[email-address. And also that you entered your email to sign up for my 101% free "Levelling Up As A SQL Developer" email bootcamp.

## CTA: Verify Email

[[standard-disclaimer]]

--

I am ready to begin when you are.

See Ya Soon,

Tech Tutor Troy

www.techtutortroy.online
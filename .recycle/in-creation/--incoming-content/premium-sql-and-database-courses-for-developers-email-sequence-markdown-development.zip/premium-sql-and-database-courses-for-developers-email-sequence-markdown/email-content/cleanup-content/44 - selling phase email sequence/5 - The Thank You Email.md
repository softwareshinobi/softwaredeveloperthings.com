# Email #5 – The Thank You Email

## email subject

I'm about to close signups

## email body

Hi,

in just a few hours I'm going to close registrations to the BOOTCAMP



Will you be one of us?

Do you want to invest in yourself for the next 10 weeks?

This is the moment to decide.

No signups after the countdown end, and the Bootcamp will only run again in 2024.



For the first time, I have the feeling that I can get somewhere with an online course - Christian

This course was a game-changer for me. the more regimented coursework made me realize I had to grind harder if I wanted to make it - Brad

There are so many little things to know and learn one couldn’t possibly learn on their own, and that’s where Flavio really makes the difference - Francisco

P.S: I have a 100% satisfaction guarantee money-back no-questions-asked for the first 14 days of the course. No risk involved!

P.S.S.: This is the last email about this course launch. If you'd like to mute the launch, click here and you'll still be signed up for my regular newsletter with weekly free tutorials.

Flavio

This email was sent to you because you are subscribed to Flavio's Newsletter. If you want to stop receiving my free tutorials, click here to unsubscribe

 

 

 




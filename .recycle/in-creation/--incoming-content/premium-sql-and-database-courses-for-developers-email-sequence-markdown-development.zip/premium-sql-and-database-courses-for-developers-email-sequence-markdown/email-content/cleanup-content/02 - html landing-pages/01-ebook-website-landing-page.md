# Level Up Your Game As A SQL Developer!

--

Are you on your journey towards learning SQL?

Then get your copy of my new SQL eBook for Developers.

## My SQL eBook Is 101% Free!!!

My free SQL book teaches you beginner and intermediate level topics around general SQL and database management and SQL Query Optimization.

In this book i teach you:

* select statements
* Grouy Bys

* Column Aliases
* Table Joins

* Views and Temporary Tables
* And More!

--

So Ready Up..

Click the link below to get my new SQL ebook for SQL Developers

[[ form: first name / email address ]]

[[ CTA: Level Up ]]
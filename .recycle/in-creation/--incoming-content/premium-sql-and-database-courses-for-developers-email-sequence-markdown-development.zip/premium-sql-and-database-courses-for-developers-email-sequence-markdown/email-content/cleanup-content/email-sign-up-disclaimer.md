## disclaimer for student squeeze page

* by entering your name and email, you agree to membership in my 101% free SQL Developer daily email bootcamp. Don't worry, i respect your privacy and I don't share your contact details with anyone else. For more information please refer to my Privacy Policy. Unsubscribe at any time.
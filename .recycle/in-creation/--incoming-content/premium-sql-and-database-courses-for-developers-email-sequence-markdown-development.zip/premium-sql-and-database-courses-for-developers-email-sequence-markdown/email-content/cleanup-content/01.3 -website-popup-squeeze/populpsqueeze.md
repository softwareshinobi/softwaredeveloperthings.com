# Join our newsletter for SQL tips and more

Join our newsletter for SQL tips and more

Monthly emails about SQL, Beekeeper Studio, big data, little data, goldilocks data, and occasional cat photos. We won't spam you or share your info with anyone.

### Form content 

Email Address

Subscribe
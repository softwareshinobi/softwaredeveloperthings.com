
# About The Author: Kyriaki Raouna

Content Creator at LearnWorlds

Kyriaki is a Content Creator for the LearnWorlds team writing about marketing and e-learning, helping course creators on their journey to create, market, and sell their online courses.

Equipped with a degree in Career Guidance, she has a strong background in education management and career success.

In her free time, she gets crafty and musical.

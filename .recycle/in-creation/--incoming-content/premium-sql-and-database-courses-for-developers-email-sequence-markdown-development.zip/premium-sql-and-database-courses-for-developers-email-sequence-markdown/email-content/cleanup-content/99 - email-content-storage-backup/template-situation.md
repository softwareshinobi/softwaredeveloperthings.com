
# lesson template

## subject

SQL Bootcamp Day 1: Intro To Databases

## body content

Howdy [[first-name]]!

Welcome to the first lesson of the [[mailing-list-brand-name]] brought to you by [brand-ambassador-name]] at [[brand-website]].

—

In our last lesson we talked about...

—

In this lesson we will talk about...

—

[[article content]]

—

Coming up next time we will...

—

Talk with you soon.

From my Universe to Yours,

[[brand user name]]

[[brand-website-url]]


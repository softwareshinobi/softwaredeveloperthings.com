# Your Free SQL Ebook Is Ready | Tech Tutor Troy

## Email Subject

Your Free SQL Ebook Is Ready | Tech Tutor Troy

## Email Body

Whats up [[first-name]].

Please click the linx below to download your copy of my free ebbok "levbel up as a sql developer'

### CTA: Click To Download Book (button)

If the button above doesn't work, you can also copy and paste the link below:

### CTA: URL to PDF book download

--

To Your Ascendance,

Tech Tutor Troy

www.techtutor.troy.online
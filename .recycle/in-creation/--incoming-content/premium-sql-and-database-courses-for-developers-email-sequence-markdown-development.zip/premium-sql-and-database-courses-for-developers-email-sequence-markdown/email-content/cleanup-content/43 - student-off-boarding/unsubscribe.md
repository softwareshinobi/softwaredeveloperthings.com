# Unsubscribe From The SQL Developer Bootcamp

## Email Subject

Unsubscribe from the SQL Develer Bootcamp

## Email Body

Please comfirm your email address to no longer recieve emails from the SQL Developer Bootcamp:

* [[user-email]]

## CTA: Unsubscribe

# First Comment - Register For SQL Email Bootcamp

If you learned something with me Today, you should sign up for my 101% free SQL Developer Email Bootcamp to learn even more.

In this free SQL Developer email bootcamp you will learn:

SELECT Statements, Group Bys, Joins, Views, and more!

--

Click the link below to register for the SQL Developer Bootcamp and level up as a Developer.

<< link to website landing page >>
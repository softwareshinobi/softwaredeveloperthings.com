# First Comment: Download Free SQL eBook

If you learned something with me Today, you should grab a copy of my 101% free Introduction to SQL eBook.

In this free eBook you will learn:

SELECT Statements, Group Bys, Joins, Views, and more!

--

Click the link below to download your copy of my Introduction to SQL eBook.

<< link to website landing page >>


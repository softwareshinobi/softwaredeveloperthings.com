# First Comment - Register For SQL Email Bootcamp

If you learned something new today, you should sign up for my 101% free SQL Email Bootcamp.

The SQL Email Bootcamp is 10 days of SQL training to help you up-skill and perform better on Technical Interviews.

--

<< link to website landing page >>

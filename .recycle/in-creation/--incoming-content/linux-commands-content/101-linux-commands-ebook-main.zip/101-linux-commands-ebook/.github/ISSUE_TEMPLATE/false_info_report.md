---
name: ❌ False / Missleading / Outdated information
about: Create a report to help us improve the book 🤘
title: "False: "
labels: false-information
---

<!-- Before creating a false-info report, make sure to test the commands in your own environment to be certain it is wrong. -->

### Note the false / missleading / outdated information

<!-- A link to the false information. -->

### Additional context

<!-- Add any other context about the problem or helpful links here. -->
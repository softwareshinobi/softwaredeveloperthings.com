---
name: 📝 Chapter request
about: Suggest a chapter for the book 💡
title: "Chapter: "
labels: chapter, enhancement
---

### Is your chapter request missing? Please describe the command.

<!-- A command suggestion. Ex. I think it will be a good idea to include ```man``` to the list [...] -->

### Additional context

<!-- Add any suggestions to how the chapter could be written best. -->
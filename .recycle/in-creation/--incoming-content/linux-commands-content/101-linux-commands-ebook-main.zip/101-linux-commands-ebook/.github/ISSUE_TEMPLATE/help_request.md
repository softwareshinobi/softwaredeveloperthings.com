---
name: 🖐 Help request
about: I do not understand a command / I can't use a command from the book 😕
title: "Help: "
labels: help wanted
---

### Please fill out this template

<!-- A clear and concise description of what the problem is. Ex. I need help with [...] -->


### Additional context

<!-- Add any other context or screenshots about the feature request here. -->
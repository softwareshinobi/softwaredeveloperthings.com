// source: https://squidfunk.github.io/mkdocs-material/reference/code-blocks/#highlight
document$.subscribe(() => {
    hljs.highlightAll()
})

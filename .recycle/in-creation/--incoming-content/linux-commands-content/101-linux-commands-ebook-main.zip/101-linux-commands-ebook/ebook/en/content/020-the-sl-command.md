# The `sl` command

The `sl` command in Linux is a humorous program that runs a steam locomotive(sl) across your terminal.

![image](https://i.imgur.com/CInBHak.png)

## Installation

Install the package before running.

```
sudo apt install sl
```

## Syntax

```
sl
```

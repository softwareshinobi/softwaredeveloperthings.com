# The `exit` command

The `exit` command is used to terminate (close) an active shell session

### Syntax:
```
exit
```

***Shortcut:** Instead of typing `exit`, press `ctrl + D`, it will do the same Functionality.*